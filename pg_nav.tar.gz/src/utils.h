/*
 * utils.h
 *
 *  Created on: 4 avr. 2015
 *      Author: jfellus
 */

#ifndef PG_UTILS_H_
#define PG_UTILS_H_

#include <stdint.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <list>
#include <algorithm>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sstream>


template <typename T> class array {
public:
	std::vector<T> v;
public:
	array() {}

	inline void add(const T& e) {v.push_back(e);}

	inline bool remove(const T& e) {
		typename std::vector<T>::iterator position = std::find(v.begin(), v.end(), e);
		if (position != v.end()) {v.erase(position); return true;}
		return false;
	}

	inline size_t size() {return v.size();}

	inline T& operator[](int i) {return v[i];}
};


#define TOSTRING(x) ( ( (std::ostringstream &) (std::ostringstream().seekp( 0, std::ios_base::cur) << x )   ) . str() )

inline void copy_file_to(const std::string& filename, std::ofstream& f) {
	std::ifstream i(filename.c_str());
	std::string line;
	while (std::getline(i, line)) {
		f << line << "\n";
	}
	i.close();
}

inline void write_cpp_comment_box(std::ofstream& f, const std::string& s) {
	for(uint i=0; i<s.length()+(2+2+1+1); i++) f << "/"; f<<"\n";
	f << "// " << s << " //\n";
	for(uint i=0; i<s.length()+(2+2+1+1); i++) f << "/"; f<<"\n";
}

#endif /* UTILS_H_ */
