/*
 * pg.h
 *
 *  Created on: 5 avr. 2015
 *      Author: jfellus
 */

#ifndef PG_H_
#define PG_H_


#include "utils.h"


#define OUTPUT(type,member) inline operator type &() {return member;}


template <typename T> class In {
	T* e;
public:
	inline void init() {}
	inline void process(T& _e) { e=&_e; }
	OUTPUT(T, *e);
};

template <typename T> class Out {
	T* e;
public:
	inline void init() {}
	inline void process(T& _e) { e=&_e; }
	OUTPUT(T, *e);
};




class ImageRGB {
public:
	unsigned char* data;
	uint w, h;
public:
	ImageRGB() {		data = 0; w = h = 0;	}
	ImageRGB(uint w, uint h) : w(w), h(h) {init();}

	void init() {data = new unsigned char[w*h*3];}

	inline void process(){}

	inline unsigned char* operator()(int x, int y) { return &data[(y*w+x)*3]; }
	inline operator unsigned char*() {return data;}
};

class Image {
public:
	unsigned char* data;
	uint w, h;
public:
	Image(uint w, uint h) : w(w), h(h) {
		data = new unsigned char[w*h];
	}

	inline void process(){}

	inline unsigned char* operator()(int x, int y) { return &data[(y*w+x)]; }
	inline operator unsigned char*() {return data;}
};



class Matrix {
public:
	float* data;
	uint w,h;

	OUTPUT(float*, data)

public:
	Matrix() {data = 0; w = h = 0;}

	Matrix(uint h, uint w) {
		init(w,h);
	}

	inline void init() { if(w && h) init(w,h); }

	inline void init(uint w, uint h) {
		this->w = w; this->h = h;
		data = new float[w*h];
	}

	inline void process(){}

	inline float& operator()(int i, int j) {return data[i*w+j];}
	inline float& operator[](int i) {return data[i];}
};

















//////////


class DumpMatrix {
public:
	void init() {}

	void process(Matrix& m) {
		for(int i=0; i<m.h; i++) {
			for(int j=0; j<m.w; j++) {
				if(j!=0) std::cout << " ";
				std::cout << m(i,j);
			}
			std::cout << "\n";
		}
	}

};
#endif /* PG_H_ */
